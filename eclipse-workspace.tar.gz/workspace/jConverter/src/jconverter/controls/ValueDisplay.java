package jconverter.controls;

import javax.swing.JLabel;

import jconverter.common.Control;
import jconverter.common.Unit;

/**
 * Displays a value using specified unit.
 */
public class ValueDisplay extends Control<JLabel> {
	private Unit unit = null;
	private double value = 0.0;
	
	public ValueDisplay() {
		super(new JLabel());
	}
	
	/**
	 * Set unit in which the value should be displayed.
	 *
	 * @param unit used to display the value.
	 */
	public void setUnit(Unit unit) {
		this.unit = unit;
		updateDisplay();
	}
	
	/**
	 * Get unit used to display the value.
	 * 
	 * @return unit used to display the value
	 */
	public Unit getUnit() {
		return this.unit;
	}
	
	/**
	 * Get the value.
	 * 
	 * @return value (default unit)
	 */
	public double getValue() {
		return value;
	}
	
	/**
	 * Set the value.
	 * 
	 * @param value (default unit)
	 */
	public void setValue(double value) {
		this.value = value;
		updateDisplay();
	}
	
	private void updateDisplay() {
		getComponent().setText(value / unit.getConversionFactor()
				   			   + " " + unit.getId());	
	}
}
