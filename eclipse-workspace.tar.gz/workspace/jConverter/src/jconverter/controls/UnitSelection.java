package jconverter.controls;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;

import jconverter.Converter.FieldSpecifier;
import jconverter.common.Control;
import jconverter.common.Unit;

public class UnitSelection extends Control<JComboBox> {
	
	private final FieldSpecifier field;
	private Unit[] items = null;
	
	public UnitSelection(FieldSpecifier field) {
		super(new JComboBox());
		this.field = field;
		
		getComponent().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				onUnitChanged(getFieldSpecifier(), getUnit());
			}
		});
	}
	
	/**
	 * Get whether this is LEFT or RIGHT control.
	 * 
	 * @return type of this input/output control (LEFT/RIGHT)
	 */
	public FieldSpecifier getFieldSpecifier() {
		return field;
	}
	
	/**
	 * Set units from which user can select.
	 * 
	 * @param units available for selection
	 */
	public void setAvailableUnits(Unit[] units) {
		this.items = Arrays.copyOf(units, units.length);
		getComponent().setModel(new DefaultComboBoxModel(items));
	}
	
	/**
	 * Get the currently selected unit.
	 * 
	 * @return selected unit
	 */
	public Unit getUnit() {
		return this.items[getComponent().getSelectedIndex()];
	}
	
	/**
	 * This function is called when selects a new unit.
	 * 
	 * @param field indicated which field it is (LEFT or RIGHT)
	 * @param unit selected by user
	 */
	public void onUnitChanged(FieldSpecifier field, Unit unit) {
		// TODO: Set the unit on the correct input/output control (ie. LEFT or RIGHT)
	}
}
