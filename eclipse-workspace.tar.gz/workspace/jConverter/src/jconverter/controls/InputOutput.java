package jconverter.controls;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;

import jconverter.Converter;
import jconverter.Converter.FieldSpecifier;
import jconverter.common.Control;
import jconverter.common.Unit;

/**
 * Class implementing input/output of values for conversion.
 */
public class InputOutput extends Control<JTextField> {
	private final FieldSpecifier field;
	private double value = 0;
	private Unit unit = null;

	/**
	 * Create input/output control
	 * 
	 * @param field specifier, LEFT or RIGHT
	 */
	public InputOutput(FieldSpecifier field) {
		super(new JTextField());
		this.field = field;

		getComponent().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				onValueChanged(getFieldSpecifier(), getValue());
			}
		});
	}
	
	/**
	 * Get whether this is LEFT or RIGHT control.
	 * 
	 * @return type of this input/output control (LEFT/RIGHT)
	 */
	public FieldSpecifier getFieldSpecifier() {
		return field;
	}
	
	/**
	 * Get value converted to quantity's default unit.
	 * 
	 * @return value in default unit
	 */
	public double getValue() {
		try {
			value = Double.parseDouble(getComponent().getText())
					/ unit.getConversionFactor();
		}catch (NumberFormatException ex) { /* IGNORE  */ }
		return value;
	}

	/**
	 * Set value in quantity's default unit.
	 * 
	 * @param value (in default unit)
	 */
	public void setValue(double value) {
		getComponent().setText(Double.toString(value  * unit.getConversionFactor()));
		this.value = value;
	}

	/**
	 * Get unit in which value is displayed/entered.
	 * 
	 * @return unit used by this control
	 */
	public Unit getUnit() {
		return unit;
	}

	/**
	 * Set unit used to display/enter the value.
	 * 
	 * @param unit used by this control
	 */
	public void setUnit(Unit unit) {
		this.unit = unit;
		getComponent().setText(Double.toString(value  * unit.getConversionFactor()));
	}

	/**
	 * This function is called when user enters a new value.
	 * 
	 * @param field indicated which field it is (LEFT or RIGHT)
	 * @param value entered by user
	 */
	public void onValueChanged(FieldSpecifier field, double value) {
		Converter.getInstance().updateValue(field, value);
	}
}
