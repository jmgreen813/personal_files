package jconverter.controls;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;

import jconverter.common.Control;
import jconverter.common.Quantity;

public class QuantitySelection extends Control<JComboBox> {
	
	private Quantity[] items = null;

	public QuantitySelection() {
		super(new JComboBox());
		getComponent().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				onQuantityChanged(getQuantity());
			}
		});
	}
	
	/**
	 * Set quantities available for user selection
	 * 
	 * @param quantities for user selection
	 */
	public void setAvailableQuantities(Quantity[] quantities) {
		this.items = Arrays.copyOf(quantities, quantities.length);
		getComponent().setModel(new DefaultComboBoxModel(items));
	}
	
	/**
	 *  Get currently selected quantity.
	 *  
	 * @return selected quantities
	 */
	public Quantity getQuantity() {
		return this.items[getComponent().getSelectedIndex()];
	}
	
	/**
	 * This function is called when selects a new quantity.
	 * 
	 * @param quantity selected by user
	 */
	public void onQuantityChanged(Quantity quantity) {
		// TODO: Set the quantity (and default units) 
		//       on both (LEFT and RIGHT) controls.
	}
}
