package jconverter.common;

import javax.swing.JComponent;

/**
 * Swing control helper class.
 *
 * @param <T> swing control
 */
public class Control<T extends JComponent> {
	private final T component;
	
	/**
	 * Set Swing control associated with this component.
	 * 
	 * @param component to associate
	 */
	protected Control(T component) {
		this.component = component;
	}
	
	/**
	 * Get Swing control associated with this component.
	 * 
	 * @return Swing control
	 */
	public T getComponent() {
		return component;
	}
}
