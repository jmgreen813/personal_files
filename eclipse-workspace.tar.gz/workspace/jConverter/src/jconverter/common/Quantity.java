package jconverter.common;

import java.util.ArrayList;
import java.util.Arrays;


/**
 * Class representing a quantity (like: mass, length or volume).
 */
public final class Quantity {
	private static final Quantity[] available = initialiseAvailable();
	
	private final Unit[] units;
	private final String description;

	
	private Quantity(String description, Unit[] units) {
		this.units = Arrays.copyOf(units, units.length);
		this.description = description;
	}
	
	
	/**
	 * Create all quantities available in this converter.
	 * 
	 * @return list of available quantities
	 */
	private static Quantity[] initialiseAvailable() {
		ArrayList<Quantity> types = new ArrayList<Quantity>();
		
		types.add(new Quantity("Mass", new Unit[] {
				new Unit("kg", 1.0, "Kilogram"),

				new Unit("lb", 2.2046226, "Pound"),
				new Unit("oz", 35.273962, "Ounce"),
				new Unit("st", 0.15747304, "Stone"),
			}));
		
		types.add(new Quantity("Length", new Unit[] {
			new Unit("m", 1.0, "Meter"),

			new Unit("in", 39.370079, "Inch"),
			new Unit("ft", 3.2808399, "Foot"),
			new Unit("mi", 0.00062137119, "Mile"),
			new Unit("nm", 0.0005399568, "Nautical Mile"),
		}));

		types.add(new Quantity("Speed", new Unit[] {
				new Unit("m/s", 1.0, "Meters per Second"),

				new Unit("kph", 3.6, "Kilometers per Hour"),
				new Unit("mi", 2.2369363, "Miles per Hour"),
				new Unit("kt", 1.9438445, "Knot"),
			}));

		return types.toArray(new Quantity[types.size()]);
	}
	
	/**
	 * Get available quantities.
	 * 
	 * @return available quantities
	 */
	public static Quantity[] getAvailable() {
		return available;
	}


	/**
	 * Get available units for this quantity.
	 * 
	 * @return available units
	 */
	public Unit[] getUnits() {
		return Arrays.copyOf(units, units.length);
	}
	
	/**
	 * Return default unit for this quantity (usually SI unit)
	 * 
	 * @return default unit
	 */
	public Unit getDefaultUnit() {
		return units[0];
	}
	
	/**
	 * Get human readable quantity description.
	 * 
	 * @return description
	 */
	public String getDescription() {
		return description;
	}
	
	
	public String toString() {
		return getDescription();
	}
}
