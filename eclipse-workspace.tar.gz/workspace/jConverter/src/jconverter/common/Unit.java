package jconverter.common;

/**
 * Class representing units (like: gram, pund, ounce).
 */
public final class Unit {
	private final String id;
	private final double factor;
	private final String description;
	
	protected Unit(String id, double factor, String description) {
		if (id == null || "".equals(id.trim()) || factor == 0.0)
			throw new IllegalArgumentException();
		
		this.id = id.trim();
		this.factor = factor;
		this.description = description.trim();
	}

	/**
	 * Get unit identifier (like: `g', `lb', `oz')
	 * @return
	 */
	public String getId() {
		return id;
	}
	
	/**
	 * Get conversion factor from default (SI) unit.
	 * 
	 * @return SI conversion factor
	 */
	public double getConversionFactor() {
		return factor;
	}

	/**
	 * Get human readable name of the unit (gram, pund, ounce).
	 * 
	 * @return unit name
	 */
	public String getDescription() {
		return description;
	}
	
	public String toString() {
		return getDescription() + " (" + getId() + ")";
	}
}
