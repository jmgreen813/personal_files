package jconverter;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JFrame;
import javax.swing.JPanel;

import jconverter.common.Quantity;
import jconverter.controls.InputOutput;
import jconverter.controls.QuantitySelection;
import jconverter.controls.UnitSelection;
import jconverter.controls.ValueDisplay;


public class Converter {
	/**
	 * Field specifier, left or right.
	 */
	public enum FieldSpecifier {
		LEFT,
		RIGHT,
	};
	
	private static Converter instance = null;
	
	private final JFrame frame = new JFrame("jConverter");
	
	private final QuantitySelection quantitySelection = new QuantitySelection();
	private final InputOutput leftIO = new InputOutput(FieldSpecifier.LEFT);
	private final UnitSelection leftUnit = new UnitSelection(FieldSpecifier.LEFT);
	private final InputOutput rightIO = new InputOutput(FieldSpecifier.RIGHT);
	private final UnitSelection rightUnit = new UnitSelection(FieldSpecifier.RIGHT);
	
	/// Displays value in default unit. 
	private final ValueDisplay defaultUnitDisplay = new ValueDisplay();
	
	public Converter() {
		if (instance != null)
			throw new IllegalStateException();
		
		instance = this;
	}
	
	/**
	 * Get the one and only instance of converter (Singleton)
	 * 
	 * @return converter instance
	 */
	public static Converter getInstance() {
		return instance;
	}
	
	/**
	 * Get currently selected quantity.
	 * 
	 * @return selected quantity
	 */
	public Quantity getQuantity() {
		return quantitySelection.getQuantity();
	}

	/**
	 * Get left input/output component.
	 * 
	 * @return input/output component
	 */
	public InputOutput getLeftInput() {
		return leftIO;
	}

	/**
	 * Get left unit selection component.
	 * 
	 * @return unit selection component.
	 */
	public UnitSelection getLeftUnit() {
		return leftUnit;
	}

	/**
	 * Get left input/output component.
	 * 
	 * @return input/output component
	 */
	public InputOutput getRightInput() {
		return rightIO;
	}

	/**
	 * Get right unit selection component.
	 * 
	 * @return unit selection component.
	 */
	public UnitSelection getRightUnit() {
		return rightUnit;
	}

	/**
	 * Get component used to display value in default unit
	 * 
	 * @return value display (default unit)
	 */
	public ValueDisplay getDafaultUnitDisplay() {
		return defaultUnitDisplay;
	}
	
	/**
	 * Initialises converter components.
	 */
	protected void intialiseUnits() {
		quantitySelection.setAvailableQuantities(Quantity.getAvailable());
		Quantity quantity = quantitySelection.getQuantity();
		
		//Quantity q2 = quantitySelection.getQuantity();
	
		leftUnit.setAvailableUnits(quantity.getUnits());
		
		//Uncomment line below by removing the "//" and then hit the . key
		//leftUnit
		
		leftIO.setUnit(leftUnit.getUnit());
		leftIO.setValue(0.0);
		
		rightUnit.setAvailableUnits(quantity.getUnits());
		rightIO.setUnit(rightUnit.getUnit());
		rightIO.setValue(0.0);

		defaultUnitDisplay.setUnit(quantity.getDefaultUnit());
		defaultUnitDisplay.setValue(0.0);
	}
	
	/**
	 * Initialises user interface (Swing).
	 */
	protected void initialiseUserInterface() {
		JPanel panel = new JPanel(new GridBagLayout());
	
		GridBagConstraints constr = new GridBagConstraints();
		constr.insets = new Insets(5, 5, 5, 5);
		
		constr.gridx = 0;
		constr.gridy = 0;
		constr.gridwidth = 2;
		panel.add(quantitySelection.getComponent(), constr);
		constr.gridwidth = 1;
		
		constr.gridx = 0;
		constr.gridy = 1;
		panel.add(leftUnit.getComponent(), constr);
		constr.gridx = 1;
		panel.add(rightUnit.getComponent(), constr);
		
		constr.gridx = 0;
		constr.gridy = 2;
		constr.fill = GridBagConstraints.HORIZONTAL;
		
		panel.add(leftIO.getComponent(), constr);
		constr.gridx = 1;
		panel.add(rightIO.getComponent(), constr);
		
		constr.gridx = 0;
		constr.gridy = 3;
		constr.gridwidth = 2;
		panel.add(defaultUnitDisplay.getComponent(), constr);

		frame.getContentPane().add(panel);
		frame.pack();
		frame.setVisible(true);
	}

	public void updateValue(FieldSpecifier field, double value) {
		switch (field) {
		case LEFT:
			rightIO.setValue(value);
			defaultUnitDisplay.setValue(value);
			break;
			
		case RIGHT:
			leftIO.setValue(value);
			defaultUnitDisplay.setValue(value);
			break;
		}
	}
	/**
	 * Application entry point.
	 * 
	 * @param args application arguments
	 */
	public static void main(String args[]) {
		Converter conv = new Converter();
		conv.intialiseUnits();
		conv.initialiseUserInterface();
	}
}
